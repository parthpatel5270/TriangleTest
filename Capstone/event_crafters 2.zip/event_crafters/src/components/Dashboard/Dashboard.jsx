// Dashboard.js

import React from 'react';
import './Dashboard.scss';
import EventSiteCard from '../EventSiteCards/EventSiteCards';
import { useNavigate } from 'react-router-dom';


const Dashboard = () => {
  const eventSites = [
    { id: 1, location: 'Location 1', description: 'Description of Event Site 1', owner: 'Owner 1' },
    { id: 2, location: 'Location 2', description: 'Description of Event Site 2', owner: 'Owner 2' },
    { id: 3, location: 'Location 3', description: 'Description of Event Site 3', owner: 'Owner 3' },
    { id: 4, location: 'Location 4', description: 'Description of Event Site 4', owner: 'Owner 4' },
    { id: 5, location: 'Location 5', description: 'Description of Event Site 5', owner: 'Owner 5' },
    { id: 6, location: 'Location 6', description: 'Description of Event Site 6', owner: 'Owner 6' },
    { id: 7, location: 'Location 7', description: 'Description of Event Site 7', owner: 'Owner 7' },
    { id: 8, location: 'Location 8', description: 'Description of Event Site 8', owner: 'Owner 8' },
    { id: 9, location: 'Location 9', description: 'Description of Event Site 9', owner: 'Owner 9' },
    { id: 10, location: 'Location 10', description: 'Description of Event Site 10', owner: 'Owner 10' },
  ];


  const navigate = useNavigate();

  // Function to handle "Book Now" click event
  const handleBookNowClick = (id) => {
    // Navigate to the event site page with the corresponding ID
    navigate(`/eventsite/${id}`);
  };


  return (
    <div className="dashboard">
      <div className="search-bar">
        <input type="text" placeholder="Search event sites..." />
        <button className="search-btn">Search</button>
      </div>
      <div className="event-sites">
        {eventSites.map(eventSite => (
          <EventSiteCard
            key={eventSite.id}
            location={eventSite.location}
            description={eventSite.description}
            owner={eventSite.owner}
            img="https://images.unsplash.com/photo-1624763149686-1893acf73092?q=80&w=2873&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            onBookNowClick={() => handleBookNowClick(eventSite.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
