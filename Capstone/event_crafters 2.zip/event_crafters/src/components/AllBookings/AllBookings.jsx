import React from 'react'

const AllBookings = () => {
  return (
    <div>AllBookings</div>
  )
}

export default AllBookings