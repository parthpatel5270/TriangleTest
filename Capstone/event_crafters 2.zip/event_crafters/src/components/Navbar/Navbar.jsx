import React from "react";
import Avatar from "@mui/material/Avatar";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import StickyNote2Icon from "@mui/icons-material/StickyNote2";
import "./Navbar.scss";
import { useAuth } from "../../authentication";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      await logout();
      console.log("User logged out successfully!");
      navigate("/login");
    } catch (error) {
      console.error("Error logging out:", error.message);
    }
  };
  

  return (
    <nav className="navbar">
      <div className="brand">Event Crafters</div>
      <div className="buttons">
        <Link to='/bookings' className="nav-btn">
          <StickyNote2Icon titleAccess="All Bookings" />
        </Link>
        <button className="nav-btn">
          <Avatar>JK</Avatar>
        </button>
        <button className="nav-btn" onClick={handleLogout}>
          <ExitToAppIcon titleAccess="Logout" />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
