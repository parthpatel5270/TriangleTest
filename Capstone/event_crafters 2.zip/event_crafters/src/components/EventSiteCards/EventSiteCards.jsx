import React from 'react';
import './EventSiteCards.scss';

const EventSiteCard = ({ location, description, owner, img, onBookNowClick }) => {
  return (
    <div className="event-site-card">
      <div className="card-header">
        <h3>{location}</h3>
        <p>Owner: {owner}</p>
      </div>
      <img src={img} alt={owner} />
      <div className="card-body">
        <p>{description}</p>
        <button className="book-now-btn" onClick={onBookNowClick}>Book Now</button>
      </div>
    </div>
  );
};

export default EventSiteCard;
