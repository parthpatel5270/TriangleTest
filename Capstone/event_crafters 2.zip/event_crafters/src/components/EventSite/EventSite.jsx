// EventSite.js

import React from 'react';
import { useParams } from 'react-router-dom';
import './EventSite.scss';

const EventSite = () => {
  const { id } = useParams();

  // Hard-coded event site data
  const eventSiteData = {
    id: id,
    location: 'Event Site Location',
    description: 'Description of the event site. This can include details about the facilities, amenities, and any other relevant information.',
    owner: 'Event Site Owner',
    address: 'Event Site Address',
    price: '$100 per hour',
    img:"https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=2938&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" // Sample price
  };

  return (
    <div className="event-site">
      <div className="event-site-header">
        <img src={eventSiteData.img} alt={`Event Site ${id}`} className="event-site-image" />
      </div>
      <div className="event-site-details">
        <h1>{eventSiteData.location}</h1>
        <p><strong>Description:</strong> {eventSiteData.description}</p>
        <p><strong>Owner:</strong> {eventSiteData.owner}</p>
        <p><strong>Address:</strong> {eventSiteData.address}</p>
        <p><strong>Price:</strong> {eventSiteData.price}</p>
      </div>
      <div className="booking-options">
        <h2>Book Now</h2>
        <p>You can book this event site by contacting the owner or through our booking system.</p>
        <button className="book-now-btn">Book Now</button>
      </div>
    </div>
  );
};

export default EventSite;
