import React from 'react'

const Dashboard = () => {
  return (
    <div>
      <h3>Main Page</h3>
    </div>
  )
}

export default Dashboard