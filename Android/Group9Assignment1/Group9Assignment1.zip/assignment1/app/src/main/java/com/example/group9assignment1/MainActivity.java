package com.example.group9assignment1;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView timerTextView;
    private Button startButton, stopButton, resetButton;
    private long startTime = 0;
    private long elapsedTime = 0; // New variable to keep track of elapsed time
    private Handler timerHandler = new Handler();
    //Function to show timer running
    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            long millis = System.currentTimeMillis() - startTime + elapsedTime; // Include elapsed time
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            int hours = minutes / 60;
            seconds = seconds % 60;
            minutes = minutes % 60;

            timerTextView.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));

            timerHandler.postDelayed(this, 500);
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Getting values from the variables
        timerTextView = findViewById(R.id.timerTextView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        //Start button function
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTime = System.currentTimeMillis();
                timerHandler.postDelayed(timerRunnable, 0);
                startButton.setEnabled(false); //start button disable
                stopButton.setEnabled(true); //stop button enable
                resetButton.setEnabled(true);
            }
        });

        //Stop button function
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timerHandler.removeCallbacks(timerRunnable);
                elapsedTime += System.currentTimeMillis() - startTime; // Store elapsed time
                stopButton.setEnabled(false); //stop button disable
                resetButton.setEnabled(true);
                startButton.setEnabled(true); // start button enable
            }
        });

        //Reset button function
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timerHandler.removeCallbacks(timerRunnable);
                elapsedTime = 0; // Reset elapsed time
                timerTextView.setText("00:00:00");
                resetButton.setEnabled(false);
                stopButton.setEnabled(true);//stop button disable
                startButton.setEnabled(true); //start button enable
            }
        });
    }
}
