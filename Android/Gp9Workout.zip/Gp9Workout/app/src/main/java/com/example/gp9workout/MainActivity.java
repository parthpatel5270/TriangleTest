package com.example.gp9workout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;

import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.content.Intent;

import com.example.gp9workout.model.WorkoutModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private SeekBar seekBar;
    private TextView stepCountTextView;
    private EditText heightEditText;
    private EditText weightEditText;
    private Button addSessionButton;

    private static SharedPreferences sharedPreferences;


    static  String sharedPrefKey = "WorkoutPreferences";
    static String json_key =  "workout_list";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.slider);
        stepCountTextView = findViewById(R.id.steps);
        heightEditText = findViewById(R.id.edtHeightType);
        weightEditText = findViewById(R.id.edtWeightType);
        addSessionButton = findViewById(R.id.btnSession);

        sharedPreferences = getSharedPreferences(sharedPrefKey, MODE_PRIVATE);

        // SeekBar listener
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                stepCountTextView.setText("Step Count: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Add Session button click listener
        addSessionButton.setOnClickListener(view -> {
            // Retrieve inputs
            int stepCount = seekBar.getProgress();
            int height = Integer.parseInt(heightEditText.getText().toString());
            int weight = Integer.parseInt(weightEditText.getText().toString());

            // Calculate calories burned
            double calories = Calculation.calculateCalories(stepCount, height, weight);

            // Save session details in SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();

            WorkoutModel workoutModel = new WorkoutModel(stepCount,weight,height,calories);

            this.saveObject(getApplicationContext(), workoutModel);


            // Navigate to session list activity
            startActivity(new Intent(MainActivity.this, SessionListActivity.class));
        });
    }

    //Save the added model into session
    public static void saveObject(Context context, WorkoutModel object) {
        List<WorkoutModel> objectList = getObjectList(context);
        if (objectList == null) {
            objectList = new ArrayList<>();
        }
        objectList.add(object);


        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(json_key, new Gson().toJson(objectList));
        editor.apply();
    }

    //update the list for sharedpreference
    public static List<WorkoutModel> getObjectList(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(sharedPrefKey, Context.MODE_PRIVATE);
        String json = sharedPreferences.getString(json_key, null);
        Type type = new TypeToken<List<WorkoutModel>>() {}.getType();
        return new Gson().fromJson(json, type);
    }
}

