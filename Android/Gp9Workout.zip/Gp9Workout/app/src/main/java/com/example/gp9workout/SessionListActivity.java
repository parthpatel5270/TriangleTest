package com.example.gp9workout;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.wear.widget.WearableLinearLayoutManager;
import androidx.wear.widget.WearableRecyclerView;

import com.example.gp9workout.adapter.WorkOutAdapter;
import com.example.gp9workout.databinding.ActivitySessionListBinding;
import com.example.gp9workout.model.WorkoutModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


//Session List activity class to set the data into list for a session
public class SessionListActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    ActivitySessionListBinding activitySessionListBinding;
    WearableRecyclerView sessionRecyclerView;
    List<WorkoutModel> sessionDetails = new ArrayList<>();

    WorkOutAdapter workOutAdapter;

    static  String sharedPrefKey = "WorkoutPreferences";
    static String json_key =  "workout_list";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activitySessionListBinding = ActivitySessionListBinding.inflate(getLayoutInflater());
        setContentView(activitySessionListBinding.getRoot());


        sharedPreferences = getSharedPreferences("WorkoutPreferences", MODE_PRIVATE);
        sessionRecyclerView = activitySessionListBinding.sessionRecyclerView;

        init();
    }
    //method to initiate instance
    public void init(){
        sessionRecyclerView.setHasFixedSize(true);
        sessionRecyclerView.setEdgeItemsCenteringEnabled(true);
        sessionRecyclerView.setLayoutManager(new WearableLinearLayoutManager(getApplicationContext()));

        sessionDetails = getObjectList(getApplicationContext());

        workOutAdapter = new WorkOutAdapter(sessionDetails,getApplicationContext());
        sessionRecyclerView.setAdapter(workOutAdapter);
        workOutAdapter.notifyDataSetChanged(); //changed data will get replaced

    }

    //get the list of models added to the session
    //this function will set the json data to list
    public static List<WorkoutModel> getObjectList(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(sharedPrefKey, Context.MODE_PRIVATE);
        String json = sharedPreferences.getString(json_key, null);
        Type type = new TypeToken<List<WorkoutModel>>() {}.getType();
        return new Gson().fromJson(json, type);
    }
}
