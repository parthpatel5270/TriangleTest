package com.example.gp9workout;

public class Calculation {
    public static double calculateCalories(int stepCount, int height, int weight) {
        double stride = height * 0.414;
        double distance = stride * stepCount;
        double time = distance / determineSpeed(stepCount);
        double calories = time * 3.5 * weight / (200 * 60);
        return calories;
    }

    public static double determineSpeed(int stepCount) {
        if (stepCount <= 79)
            return 0.9;
        else if (stepCount <= 99)
            return 1.34;
        else
            return 1.79;
    }
}
