package com.example.gp9workout.model;

public class WorkoutModel {
    public double steps;
    public double weight;
    public double height;
    public double calories;

    //model to set params of steps, weight, height, and calories
    public WorkoutModel(double steps, double weight, double height, double calories) {
        this.steps = steps;
        this.weight = weight;
        this.height = height;
        this.calories = calories;
    }

    public double getSteps() {
        return steps;
    }

    public void setSteps(double steps) {
        this.steps = steps;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    @Override
    public String toString() {
        return "steps:" + steps +
                " weight:" + weight +
                " height:" + height +
                " calories:" + calories;
    }
}
