package com.example.gp9workout.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gp9workout.databinding.WorkoutRowBinding;
import com.example.gp9workout.model.WorkoutModel;

import java.util.ArrayList;
import java.util.List;

public class WorkOutAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    List<WorkoutModel> workoutModelList = new ArrayList<>();
    WorkoutRowBinding workoutRowBinding;

    public WorkOutAdapter(List<WorkoutModel> workoutModelList, Context context) {
        this.workoutModelList = workoutModelList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        workoutRowBinding = WorkoutRowBinding.inflate(layoutInflater,parent,false);
        return new ViewHolder(workoutRowBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder) holder).bindView(workoutModelList.get(position));
    }

    @Override
    public int getItemCount() {
        return workoutModelList.size();
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        WorkoutRowBinding binding;
        public ViewHolder(WorkoutRowBinding workoutRowBinding) {
            super(workoutRowBinding.getRoot());
            binding = workoutRowBinding;
        }
        public void bindView(WorkoutModel workoutModel){
            binding.txtWorkout.setText(workoutModel.toString());
        }
    }
}
